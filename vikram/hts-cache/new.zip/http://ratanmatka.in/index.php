

<!DOCTYPE html>
<html lang="en">
<head>
<title> online play matka ,play matka online , online satta matka, satta matka online, satta matka online play , satta matka fix game ,satta matka fix jodi ,satta matka fast Result ,satta matka sure number, satta matka today game,satta matka fix </title>
<meta name="description" content="Game Rate Full<br/>10:100(Single Digit)<br/>10:1000(Jodi)<br/>10:1500(Single Panel)<br/>10:3000(Double Panel)<br/>10:7000(Triple Panel)<br>10:10000 (Half sangam)<br>10:100000(full sangam)<br/>

<br/>For Account Number Details And All Other Details,Contact Admin sir <br><b> Whatsapp sms 9672737576</b></font><br/> ">
<link rel="stylesheet" href="https://www.ratanmatka.in/styles.css" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-80894722-1', 'auto');
  ga('send', 'pageview');

</script>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>	
  
</head>
<body>
<div align="center" class="satta_2">
<div style="color: Red;"><span style="color: #F0FFF0;"><span style="font-family: Calibri;"><span style="font-size: x-large;"><strong><em><big><bdo dir="ltr">Ratan Matka</bdo></big></em></strong></span></span></span></div><a href="http://ratanmatka.in">RatanMatka.iN</a>
</div>

	
</div><div class="double">
PLAY ONLINE SATTA MATKA<br/><font color="green">TIME BAZAR</font>|<font color="RED">MADHUR </font>| <font color="black">MILAN </font> | <font color="#B93B8F">RAJDHANI </font>| <font color="red">KALYAN</font>| <font color="blue">MUMBAI |<font color="black">SRIDEVI </font> | <font color="black">SUPERME   </font> | <font color="RED">KALYAN STARLINE <font  | <font color="black">MUMBAI STARLINE</font><br> </font> <font <br>  <font color="black">Game Rate Full x10<br/>100:1000(Single Digit)<br/>100:10000(Jodi)<br/>100:15000(Single Panel)<br/>100:30000(Double Panel)<br/>100:70000(Triple Panel)<br>100:100000 (Half sangam)<br>100:1000000 (full sangam)<br><font color="red">
WITHDRAWAL TIME MORNING 7 am To 11.00 am</font>
<br/>
Minimum Deposit 1000/- Minimum Withdrawal 500/-<br />Withdrawal Free Hai No Charge<br><bR>      DEPOSIT  BOUNS
ALL TIME<br>10000 per 1000<br >20000 per 2000<br >50000 per 6000<br><br>NOTICE<br>Play last time update<br><br><font color="green"> <br><font color="red">For Account Number Details And All Other Details,Contact Admin Sir </font><font color="green"><b> WhatsApp sms 9672737576<br>   </font><br/></font> </p></div><div <div <div align="center"><div class="phdr2" align="center"><span style="color: #000000;"><b>Free Game Menu</b> 4 ANK</span></div></div> 
<div align="center"><div align="center" class="yellow"><b><span style="color: blue;">20.07.2020</span><br />
<span style="color: red;">KALYAN</span><br />
OPEN/CLOSE<br /
<br><br> 
    <BR> </div><div align="center" class="grey"><b><span style="color: blue;">20.07.2020</span><br />
<span style="color: red;">MAIN RATAN</span><br />
OPEN/CLOSE<br><br>
<br><br> <br></div><div align="center" class="grey"><b><span style="color: blue;">20.07.2020</span><br />
<span style="color: red;">GALI  DESAWAR<br>FARIDABAD GAZIYABAD</span><br />
ANDAR/BAHAR<br> <br><br> <br> <div class="container" style="text-align: center;">    <div <div align="center">  <h5><b>Download Ratan Matka App Now photo par cilck karo
</b></h5>
                    <a href="https://bit.ly/2AcJeH5"_blank"><img src="google_play_store.png" width="400px"></img></a></div><div 
<br/>


<br></div></div></div>  
 


<div style="text-align:center" align="center" class="google_play"><a href="whatsapp://send?text=Hello Admin Sir&phone=+919672737576"><img src="/images/whatsapp.png" width="400px" /></a><br />
<div style="text-align:center" align="center" class="telegram"><a href="https://t.me/AAAAAEkmMafQRKijB075Uw"><img src="Telegram-logo.jpg" width="400px" /></a><br />
 <div class="container" style="text-align: center;">
                    <h5><b>Whatsapp Link  photo par cilck karo</b></h5>
                    <a href="https://youtu.be/w9O173dQpm8" target="_blank"><img src="youtube.jpg" width="281px"></img></a> &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;
                    </br><br><br> <h5><a href="https://youtu.be/w9O173dQpm8" style="color:red">Click To Subscribe Channel</a></h5>
                </div>Plzz Subscribe My YouTube Channel photo par cilck karo </br></br>
<div class="purple"><form action="login.php" name="login" method="post"><input type="hidden" name="s" value="1" />Username: <input type="text" name="username">&nbsp;Password: <input type="password" name="password">&nbsp;&nbsp;<input type="submit" value="Login">&nbsp;&nbsp;&nbsp;&nbsp;New user <a href="register.php"><input type="button" name="register" value="Register" class="btn"></a> &nbsp;&nbsp; here&nbsp;&nbsp;</form></div>
<div class="detail"><a href="index.php"><input type="button" value="Home"  class="btn"></a>&nbsp;<a href="game9.php"><input type="button" value="Single"  class="btn"></a>&nbsp;<a href="game90.php"><input type="button" value="Jodi"  class="btn"></a>&nbsp;<a href="game125.php"><input type="button" value="Single Patti"  class="btn"></a>&nbsp;<a href="game250.php"><input type="button" value="Double Patti"  class="btn"></a>&nbsp;<a href="game600.php"><input type="button" value="Tripple Patti" class="btn"></a>&nbsp;<a href="game1000.php"><input type="button" value="Half Sangam"  class="btn"></a>&nbsp;<a href="game10000.php"><input type="button" value="Full Sangam" class="btn"></a>&nbsp;
 
<a href="stargame.php?gamename=ksl">
    <input type="button" value="KALYAN STARLINE" class="btn">
</a>
<a href="stargame.php?gamename=msl">
    <input type="button" value="MUMBAI STARLINE" class="btn">
</a>
 
  <a href="/freegamepost.php"><input type="button" value="Game Rate"  class="btngm"></a>&nbsp;<a href="info.php"><input type="button" value="How To Play?"  class="btn"></a>&nbsp;</div>



<div style="background-color: orange">

<div align="center"><div class="phdr2" align="center"><span style="color: #000000;"><b>Result Menu</b></span></div></div> 
<div align="center">
  <table width="100%">
    <tr>
        <td colspan="2"><div class="yellow" align="center"><br/><b>TIME BAZAR<br/><span style="color: red;">366-51-470</span></b><br/><br/></div></td>
      </tr>
   
      <tr>
          <td width="49%"><div class="yellow" align="center"><br/><b>SRIDEVI DAY<br/><span style="color: red;">378-85-159</span></b><br/><br/></div></td>
          <td width="49%"><div class="yellow" align="center"><br/><b>SRIDEVI NIGHT<br/><span style="color: red;">137-14-590</span></b><br/><br/></div></td>
      </tr>
      <!--
        
      -->

  </table>
<font size ="15"><div id="myClock"></div></font>
<script type="text/javascript" language="javascript"> 

// select the myClock div
var myClock = document.getElementById('myClock');

function renderTime () {

    var currentTime = new Date();
    var h = currentTime.getHours();
    var m = currentTime.getMinutes();
    var s = currentTime.getSeconds();
if (h<12) { pkk= "AM"; } else {pkk= "PM"; }

    if(h==0){h=12;}
	else if(h>12){h-=12;}
    
    
    if (m < 10) 
    { m = "0" + m;
    }
    
    
    if (s < 10) 
    { s = "0" + s;
    }
    
    myClock.textContent = h + ":" + m + ":" + s   +   pkk;
    myClock.innerText = h + ":" + m + ":" + s   +   pkk;

} // don't forget to close your function

// you actually want to use setInterval, not setTimeout
setInterval(function(){
    renderTime();
}, 1000);
</script>

<table width="100%"><tr><td width="49%"><div class="yellow" align="center"><br/><b>MADHUR DAY<br/><span style="color: red;">269-76-240</span></b><br/><br/></div></td>
<td width="49%"><div class="yellow" align="center"><br/><b>MADHUR NIGHT<br/><span style="color: red;">399-14-248</span></b><br/><br/></div></td>
</tr></table>

<!-- <table width="100%"><tr>
  <td width="49%"><div class="yellow" align="center"><br/><b>SUPERME DAY<br/><span style="color: red;">689-3-</span></b><br/><br/></div></td>
<td width="49%"><div class="yellow" align="center"><br/><b>SUPERME NIGHT<br/><span style="color: red;">558-81-128</span></b><br/><br/></div></td>
</tr></table> -->
<table width="100%"><tr>
<td width="49%"><div class="grey" align="center"><br/><b>SUPERME DAY<br/><span style="color: red;">689-3-</span></b><br/><br/></div></td>

          <td width="49%"><div class="yellow" align="center"><br/><b>SUPERME NIGHT<br/><span style="color: red;">558-81-128</span></b><br/><br/></div></td>
</tr></table>

<table width="100%">
  <tr>
    <td width="33%"><div class="grey" align="center"><br/><b>RAJDHANI DAY<br/><span style="color: red;">479-0-</span></b><br/><br/></div></td>
    <td width="34%"><div class="yellow" align="center"><br/><b>MILAN DAY<br/><span style="color: red;">460-0-</span></b><br/><br/></div></td>
    <td width="33%"><div class="grey" align="center"><br/><b>KALYAN<br/><span style="color: red;">558-8-</span></b><br/><br/></div></td>
  </tr>
        
  <tr>
    <td><div class="yellow" align="center"><br/><b>RAJDHANI NIGHT<br/><span style="color: red;">139-32-570</span></b><br/><br/></div></td>
    <td><div class="grey" align="center"><br/><b>MILAN NIGHT<br/><span style="color: red;">789-48-567</span></b><br/><br/></div></td>
    <td><div class="yellow" align="center"><br/><b>MAIN RATAN<br/><span style="color: red;">268-61-290</span></b><br/><br/></div></td>
<!-- <td width="33%"><div class="yellow" align="center"><br/><b><br/><span style="color: red;">--</span></b><br/><br/></div></td> -->



</tr> </table>
</div> 
<style type="text/css">
  .bannerimage{width: 100%;}
  .bannerimage img{ max-height: 100%;max-width: 100% }
</style>
<style type="text/css">
  ul.small_image li{display: inline-block;height: 500px;vertical-align: top;padding: 0;}

  .todaywidal {
  width: 100%;
  text-align: center;
  
  background-color: #ffffcc;
  padding: 10px 0px;
  display:block;

}
.todaywidal > label{font-size: 25px !important;}
</style></div></td></tr> </table></div> 

<div class="footer">&copy; 2011-2035  Ratan Matka Inc.</div>