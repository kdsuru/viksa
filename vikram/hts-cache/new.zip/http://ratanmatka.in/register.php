<!DOCTYPE html>
<html lang="en">
<head>
<title>online play matka ,play matka online ,online matka play,online matka, matka online, online matka play, matka play, online satta matka, satta matka online, satta matka online play, satta matka online play , satta matka fix game ,satta matka fix jodi ,satta matka fast Result ,satta matka sure number, satta matka today game,satta matka fix  Registeration</title>
<meta name="description" content="online play matka ,play matka online ,online matka play,online matka, matka online, online matka play, matka play, online satta matka, satta matka online, satta matka online play, satta matka online play , satta matka fix game ,satta matka fix jodi ,satta matka fast Result ,satta matka sure number, satta matka today game,satta matka fix  Registeration">


<link rel="stylesheet" href="/styles.css" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-80894722-1', 'auto');
  ga('send', 'pageview');

</script>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>	
  
</head>
<body>

<div class="purple"><form action="login.php" name="login" method="post"><input type="hidden" name="s" value="1" />Username: <input type="text" name="username">&nbsp;Password: <input type="password" name="password">
&nbsp;<input type="submit" value="Login">&nbsp;&nbsp; &nbsp;&nbsp; New user <a href="register.php"><input type="button" name="register" value="Register"  class="btn"></a> here</form></div>

<div style="background-color: orange"><form action="register.php" method="POST"><input type="hidden" name="s" value="1" />
<table>
<tr><tr><td width="40%">Username: </td><td><input type="text" name="username"></td></tr><tr><td width="40%">Password: </td><td><input type="password" name="pass1"></td></tr><tr><td width="40%">Repeat Password: </td><td><input type="password" name="pass2"></td></tr><tr><td width="40%">Mobile: </td><td><input type="text" name="mobile"></td></tr><tr><td width="40%">Bank name: </td><td><input type="text" name="bankname"></td></tr><tr><td width="40%">Bank IFSC: </td><td><input type="text" name="ifsc"></td></tr><td width="60%">Account Holder Name: </td><td><input type="text" name="acname"></td></tr><tr><td width="40%">Account number: </td><td><input type="text" name="acno"></td></tr>
<tr><td width="40%">Paytm: </td><td><input type="text" name="paytm"></td></tr><td width="60%">Airtel Money: </td><td><input type="text" name="airtelmoney"></td></tr>
<tr><td width="40%">Bhim: </td><td><input type="text" name="bhim"></td></tr>
<tr><td width="60%">Tez: </td><td><input type="text" name="tez"></td></tr><tr><td width="40%">PhonePe: </td><td><input type="text" name="phonepe"></td>
</tr>

<tr><td width="40%">&nbsp;</td><td><input type="Submit" value="Register"></td></tr></table></form></div>

</div></td></tr> </table></div> 

<div class="footer">&copy; 2011-2035  Ratan Matka Inc.</div>