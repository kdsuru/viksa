 
<!DOCTYPE html>
<html lang="en">
<head>
<title>Play Matka online  Satta Matka of all markets Play Double Patti</title>
<meta name="description" content="Play Online Satta Matka of all markets Play Double Patti">


<link rel="stylesheet" href="/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-80894722-1', 'auto');
  ga('send', 'pageview');

</script>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>	
  
</head>
<body>
<div align="center" class="satta_2">
<div style="color: Red;"><span style="color: #F0FFF0;"><span style="font-family: Calibri;"><span style="font-size: x-large;"><strong><em><big><bdo dir="ltr">Ratan Matka</bdo></big></em></strong></span></span></span></div><a href="http://ratanmatka.in">RatanMatka.iN</a>
</div>
<div class="detail"><marquee behavior="alternate">After Registration, for online play Contact us on +919672737576
</marquee></div> PHONE PE:9672737576<br>GOOGLE PAY:9672737576<br>PAYTM:9672737576<br>BHIM 9672737576<br><div class="purple"><form action="login.php" name="login" method="post"><input type="hidden" name="s" value="1" />Username: <input type="text" name="username">&nbsp;Password: <input type="password" name="password">&nbsp;&nbsp;<input type="submit" value="Login">&nbsp;&nbsp;&nbsp;&nbsp;New user <a href="register.php"><input type="button" name="register" value="Register" class="btn"></a> &nbsp;&nbsp; here&nbsp;&nbsp;</form></div>
<div style="background-color: orange">
<center>TODAY'S  DATE: 17/07/2020<br /><font size ="15"><div id="myClock"></div></font>
<script type="text/javascript" language="javascript">

// select the myClock div
var myClock = document.getElementById('myClock');

function renderTime () {

    var currentTime = new Date();
    var h = currentTime.getHours();
    var m = currentTime.getMinutes();
    var s = currentTime.getSeconds();
if (h<12) { pkk= "AM"; } else {pkk= "PM"; }

    if(h==0){h=12;}
	else if(h>12){h-=12;}
    
    
    if (m < 10) 
    { m = "0" + m;
    }
    
    
    if (s < 10) 
    { s = "0" + s;
    }
    
    myClock.textContent = h + ":" + m + ":" + s   +   pkk;
    myClock.innerText = h + ":" + m + ":" + s   +   pkk;

} // don't forget to close your function

// you actually want to use setInterval, not setTimeout
setInterval(function(){
    renderTime();
}, 1000);
</script>
</div></center><form action="play.php" id="form1" method="post"><input type="hidden" name="s" value="1" /><input name="selrs" type="text" value="" style="display: none">
<table width="100%" lol ><tr>

<td class="g_d">SRIDEVI DAY OPEN<br>11.20 AM</td>
<td class="g_d">MADHUR DAY OPEN<br>1:00 PM</td>
<td class="g_d">TIME BAZAR OPEN<br>12:50 PM</td>
<td class="g_d">MILAN DAY OPEN<br>02:55 PM</td>
<td class="g_d">RAJDHANI DAY OPEN<br>03:15 PM</td>
<td class="g_d">SUPERME DAY OPEN<br>03.20 PM</td>
<td class="g_d">KALYAN OPEN<br>03:50 PM</td>
<td class="g_g">SRIDEVI NIGHT OPEN<br>06.50 PM</td>
<td class="g_g">SUPERME NIGHT OPEN<br>08.30 PM</td>
<td class="g_g">MADHUR NIGHT OPEN<br>08:10 PM</td>
<td class="g_g">MILAN NIGHT OPEN<br>08:50 PM</td>
<td class="g_g">RAJDHANI NIGHT OPEN<br>09:20 PM</td>
<td class="g_g">MAIN RATAN OPEN<br>09:30 PM</td>
</tr>
<tr>


<td class="g_d">SRIDEVI DAY CLOSE<br>12.20 PM</td>
<td class="g_d">MADHUR DAY CLOSE<br>02:00 PM</td>
<td class="g_d">TIME BAZAR CLOSE<br>01:50 PM</td>
<td class="g_g">MILAN DAY CLOSE<br>04:55 PM</td>
<td class="g_g">RAJDHANI DAY CLOSE<br>05:15 PM</td>
<td class="g_g">SUPERME DAY CLOSE<br>05.20 PM</td>
<td class="g_g">KALYAN CLOSE<br>05:50 PM</td>
<td class="g_g">SRIDEVI NIGHT CLOSE<br>07.50 PM</td>
<td class="g_g">SUPERME NIGHT CLOSE<br>10.30 PM</td>
<td class="g_g">MADHUR NIGHT CLOSE<br>10:10 PM</td>
<td class="g_g">MILAN NIGHT CLOSE<br>10:50 PM</td>
<td class="g_g">RAJDHANI NIGHT CLOSE<br>11:40 PM</td>
<td class="g_g">MAIN RATAN CLOSE<br>11:55 PM</td>
</tr>
</table><table class="player" align='center' cellspacing='2' cellpadding='6' border='0' width="100%"><tr><td><div class="left_gopt">Game: 1:300</div><input type="hidden" name="game" value="DP"></td><td></td><td></td><td></td><td></td><td class="colored totx">Points</td></tr><tr><td class="colored">100&nbsp;<input id="x_0_0" onKeyup="refresh('0');" name="txt[100]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">110&nbsp;<input id="x_0_1" onKeyup="refresh('0');" name="txt[110]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">112&nbsp;<input id="x_0_2" onKeyup="refresh('0');" name="txt[112]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">113&nbsp;<input id="x_0_3" onKeyup="refresh('0');" name="txt[113]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">114&nbsp;<input id="x_0_4" onKeyup="refresh('0');" name="txt[114]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_0">00</div></td></tr><tr><td class="colored">115&nbsp;<input id="x_1_0" onKeyup="refresh('1');" name="txt[115]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">116&nbsp;<input id="x_1_1" onKeyup="refresh('1');" name="txt[116]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">117&nbsp;<input id="x_1_2" onKeyup="refresh('1');" name="txt[117]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">118&nbsp;<input id="x_1_3" onKeyup="refresh('1');" name="txt[118]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">119&nbsp;<input id="x_1_4" onKeyup="refresh('1');" name="txt[119]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_1">00</div></td></tr><tr><td class="colored">122&nbsp;<input id="x_2_0" onKeyup="refresh('2');" name="txt[122]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">133&nbsp;<input id="x_2_1" onKeyup="refresh('2');" name="txt[133]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">144&nbsp;<input id="x_2_2" onKeyup="refresh('2');" name="txt[144]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">155&nbsp;<input id="x_2_3" onKeyup="refresh('2');" name="txt[155]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">166&nbsp;<input id="x_2_4" onKeyup="refresh('2');" name="txt[166]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_2">00</div></td></tr><tr><td class="colored">177&nbsp;<input id="x_3_0" onKeyup="refresh('3');" name="txt[177]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">188&nbsp;<input id="x_3_1" onKeyup="refresh('3');" name="txt[188]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">199&nbsp;<input id="x_3_2" onKeyup="refresh('3');" name="txt[199]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">200&nbsp;<input id="x_3_3" onKeyup="refresh('3');" name="txt[200]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">220&nbsp;<input id="x_3_4" onKeyup="refresh('3');" name="txt[220]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_3">00</div></td></tr><tr><td class="colored">223&nbsp;<input id="x_4_0" onKeyup="refresh('4');" name="txt[223]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">224&nbsp;<input id="x_4_1" onKeyup="refresh('4');" name="txt[224]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">225&nbsp;<input id="x_4_2" onKeyup="refresh('4');" name="txt[225]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">226&nbsp;<input id="x_4_3" onKeyup="refresh('4');" name="txt[226]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">227&nbsp;<input id="x_4_4" onKeyup="refresh('4');" name="txt[227]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_4">00</div></td></tr><tr><td class="colored">228&nbsp;<input id="x_5_0" onKeyup="refresh('5');" name="txt[228]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">229&nbsp;<input id="x_5_1" onKeyup="refresh('5');" name="txt[229]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">233&nbsp;<input id="x_5_2" onKeyup="refresh('5');" name="txt[233]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">244&nbsp;<input id="x_5_3" onKeyup="refresh('5');" name="txt[244]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">255&nbsp;<input id="x_5_4" onKeyup="refresh('5');" name="txt[255]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_5">00</div></td></tr><tr><td class="colored">266&nbsp;<input id="x_6_0" onKeyup="refresh('6');" name="txt[266]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">277&nbsp;<input id="x_6_1" onKeyup="refresh('6');" name="txt[277]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">288&nbsp;<input id="x_6_2" onKeyup="refresh('6');" name="txt[288]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">299&nbsp;<input id="x_6_3" onKeyup="refresh('6');" name="txt[299]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">300&nbsp;<input id="x_6_4" onKeyup="refresh('6');" name="txt[300]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_6">00</div></td></tr><tr><td class="colored">330&nbsp;<input id="x_7_0" onKeyup="refresh('7');" name="txt[330]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">334&nbsp;<input id="x_7_1" onKeyup="refresh('7');" name="txt[334]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">335&nbsp;<input id="x_7_2" onKeyup="refresh('7');" name="txt[335]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">336&nbsp;<input id="x_7_3" onKeyup="refresh('7');" name="txt[336]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">337&nbsp;<input id="x_7_4" onKeyup="refresh('7');" name="txt[337]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_7">00</div></td></tr><tr><td class="colored">338&nbsp;<input id="x_8_0" onKeyup="refresh('8');" name="txt[338]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">339&nbsp;<input id="x_8_1" onKeyup="refresh('8');" name="txt[339]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">344&nbsp;<input id="x_8_2" onKeyup="refresh('8');" name="txt[344]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">355&nbsp;<input id="x_8_3" onKeyup="refresh('8');" name="txt[355]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">366&nbsp;<input id="x_8_4" onKeyup="refresh('8');" name="txt[366]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_8">00</div></td></tr><tr><td class="colored">377&nbsp;<input id="x_9_0" onKeyup="refresh('9');" name="txt[377]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">388&nbsp;<input id="x_9_1" onKeyup="refresh('9');" name="txt[388]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">399&nbsp;<input id="x_9_2" onKeyup="refresh('9');" name="txt[399]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">400&nbsp;<input id="x_9_3" onKeyup="refresh('9');" name="txt[400]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">440&nbsp;<input id="x_9_4" onKeyup="refresh('9');" name="txt[440]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_9">00</div></td></tr><tr><td class="colored">445&nbsp;<input id="x_10_0" onKeyup="refresh('10');" name="txt[445]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">446&nbsp;<input id="x_10_1" onKeyup="refresh('10');" name="txt[446]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">447&nbsp;<input id="x_10_2" onKeyup="refresh('10');" name="txt[447]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">448&nbsp;<input id="x_10_3" onKeyup="refresh('10');" name="txt[448]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">449&nbsp;<input id="x_10_4" onKeyup="refresh('10');" name="txt[449]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_10">00</div></td></tr><tr><td class="colored">455&nbsp;<input id="x_11_0" onKeyup="refresh('11');" name="txt[455]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">466&nbsp;<input id="x_11_1" onKeyup="refresh('11');" name="txt[466]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">477&nbsp;<input id="x_11_2" onKeyup="refresh('11');" name="txt[477]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">488&nbsp;<input id="x_11_3" onKeyup="refresh('11');" name="txt[488]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">499&nbsp;<input id="x_11_4" onKeyup="refresh('11');" name="txt[499]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_11">00</div></td></tr><tr><td class="colored">500&nbsp;<input id="x_12_0" onKeyup="refresh('12');" name="txt[500]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">550&nbsp;<input id="x_12_1" onKeyup="refresh('12');" name="txt[550]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">556&nbsp;<input id="x_12_2" onKeyup="refresh('12');" name="txt[556]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">557&nbsp;<input id="x_12_3" onKeyup="refresh('12');" name="txt[557]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">558&nbsp;<input id="x_12_4" onKeyup="refresh('12');" name="txt[558]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_12">00</div></td></tr><tr><td class="colored">559&nbsp;<input id="x_13_0" onKeyup="refresh('13');" name="txt[559]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">566&nbsp;<input id="x_13_1" onKeyup="refresh('13');" name="txt[566]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">577&nbsp;<input id="x_13_2" onKeyup="refresh('13');" name="txt[577]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">588&nbsp;<input id="x_13_3" onKeyup="refresh('13');" name="txt[588]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">599&nbsp;<input id="x_13_4" onKeyup="refresh('13');" name="txt[599]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_13">00</div></td></tr><tr><td class="colored">600&nbsp;<input id="x_14_0" onKeyup="refresh('14');" name="txt[600]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">660&nbsp;<input id="x_14_1" onKeyup="refresh('14');" name="txt[660]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">667&nbsp;<input id="x_14_2" onKeyup="refresh('14');" name="txt[667]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">668&nbsp;<input id="x_14_3" onKeyup="refresh('14');" name="txt[668]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">669&nbsp;<input id="x_14_4" onKeyup="refresh('14');" name="txt[669]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_14">00</div></td></tr><tr><td class="colored">677&nbsp;<input id="x_15_0" onKeyup="refresh('15');" name="txt[677]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">688&nbsp;<input id="x_15_1" onKeyup="refresh('15');" name="txt[688]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">699&nbsp;<input id="x_15_2" onKeyup="refresh('15');" name="txt[699]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">700&nbsp;<input id="x_15_3" onKeyup="refresh('15');" name="txt[700]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">770&nbsp;<input id="x_15_4" onKeyup="refresh('15');" name="txt[770]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_15">00</div></td></tr><tr><td class="colored">778&nbsp;<input id="x_16_0" onKeyup="refresh('16');" name="txt[778]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">779&nbsp;<input id="x_16_1" onKeyup="refresh('16');" name="txt[779]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">788&nbsp;<input id="x_16_2" onKeyup="refresh('16');" name="txt[788]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">799&nbsp;<input id="x_16_3" onKeyup="refresh('16');" name="txt[799]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">800&nbsp;<input id="x_16_4" onKeyup="refresh('16');" name="txt[800]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_16">00</div></td></tr><tr><td class="colored">880&nbsp;<input id="x_17_0" onKeyup="refresh('17');" name="txt[880]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">889&nbsp;<input id="x_17_1" onKeyup="refresh('17');" name="txt[889]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">899&nbsp;<input id="x_17_2" onKeyup="refresh('17');" name="txt[899]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">900&nbsp;<input id="x_17_3" onKeyup="refresh('17');" name="txt[900]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">990&nbsp;<input id="x_17_4" onKeyup="refresh('17');" name="txt[990]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_17">00</div></td></tr><tr><td></td><td></td><td></td><td></td><td class="colored smx"><b>Total -></b></td><td class="colored totx"><span id="whole">00</div></td></tr></table>
<div style="color: red; padding:5px;" align="center">
You can not play game. Your account balance should be greater than 5. contact to administrator.</div>
<center><font color=blue>*After Confirm Submission no changes will be made at any cost and it will be fixed bidding</font><br><b><br>Note - Minimum Bet on any any number should be 10 points</b></center>
<script>
function refresh(id)
{
sum=0;

for(i=0; i<5; i++)
{
points = document.getElementById("x_" + id + "_" + i).value;
if(points > )
{
alert("You dont have that much point.");
}else{
sum = +sum + +points;
}
document.getElementById("t_r_" + id).innerHTML = sum;
}
refreshall('18');
}

function refreshall(all)
{
sum = 0;
for(i=0; i<all; i++)
{
sum = +sum + +document.getElementsByClassName("smd")[i].innerHTML;
}
document.getElementById("whole").innerHTML = sum;
if(sum > )
{
alert("You dont have that much point.");
}
}

function rst(tot)
{
document.getElementById("form1").reset();
document.getElementById("whole").innerHTML = "00";
for(i=0; i<tot; i++)
{
document.getElementsByClassName("smd")[i].innerHTML = "00";
}
}

</script>
</div></td></tr> </table></div> 

<div class="footer">&copy; 2011-2035  Ratan Matka Inc.</div>