 <!DOCTYPE html>
<html lang="en">
<head>
<title>Play Matka online  Satta Matka of all markets Play Jodi</title>
<meta name="description" content="Play Online Satta Matka of all markets Play Jodi">


<link rel="stylesheet" href="/styles.css" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-80894722-1', 'auto');
  ga('send', 'pageview');

</script>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>	
  
</head>
<body>

<div align="center" class="satta_2">
<div style="color: Red;"><span style="color: #F0FFF0;"><span style="font-family: Calibri;"><span style="font-size: x-large;"><strong><em><big><bdo dir="ltr">Ratan Matka</bdo></big></em></strong></span></span></span></div><a href="http://ratanmatka.in">RatanMatka.iN</a>
</div>
<div class="detail"><marquee behavior="alternate">After Registration, for online play Contact us on +919672737576
</marquee></div> PHONE PE:9672737576<br>GOOGLE PAY:9672737576<br>PAYTM:9672737576<br>BHIM 9672737576<br>
<div class="purple"><form action="login.php" name="login" method="post"><input type="hidden" name="s" value="1" />Username: <input type="text" name="username">&nbsp;Password: <input type="password" name="password">&nbsp;&nbsp;<input type="submit" value="Login">&nbsp;&nbsp;&nbsp;&nbsp;New user <a href="register.php"><input type="button" name="register" value="Register" class="btn"></a> &nbsp;&nbsp; here&nbsp;&nbsp;</form></div><div style="background-color: orange">
<center>TODAY'S  DATE: 17/07/2020<br /><font size ="15"><div id="myClock"></div></font>
<script type="text/javascript" language="javascript">

// select the myClock div
var myClock = document.getElementById('myClock');

function renderTime () {

    var currentTime = new Date();
    var h = currentTime.getHours();
    var m = currentTime.getMinutes();
    var s = currentTime.getSeconds();
if (h<12) { pkk= "AM"; } else {pkk= "PM"; }

    if(h==0){h=12;}
	else if(h>12){h-=12;}
    
    
    if (m < 10) 
    { m = "0" + m;
    }
    
    
    if (s < 10) 
    { s = "0" + s;
    }
    
    myClock.textContent = h + ":" + m + ":" + s   +   pkk;
    myClock.innerText = h + ":" + m + ":" + s   +   pkk;

} // don't forget to close your function

// you actually want to use setInterval, not setTimeout
setInterval(function(){
    renderTime();
}, 1000);
</script>
</div></center><form action="play.php" id="form1" method="post"><input type="hidden" name="s" value="1" />
<input name="selrs" type="text" value="" style="display: none">
<table width="100%" lol 1><tr>

<td class="g_d">SRIDEVI DAY OPEN<br>11.20 AM</td>
<td class="g_d">MADHUR DAY OPEN<br>1:00 PM</td>
<td class="g_d">TIME BAZAR OPEN<br>12:50 PM</td>
<td class="g_d">MILAN DAY OPEN<br>02:55 PM</td>
<td class="g_d">RAJDHANI DAY OPEN<br>03:15 PM</td>
<td class="g_d">SUPERME DAY OPEN<br>03.20 PM</td>
<td class="g_d">KALYAN OPEN<br>03:50 PM</td>
<td class="g_g">SRIDEVI NIGHT OPEN<br>06.50 PM</td>
<td class="g_g">SUPERME NIGHT OPEN<br>08.30 PM</td>
<td class="g_g">MADHUR NIGHT OPEN<br>08:10 PM</td>
<td class="g_g">MILAN NIGHT OPEN<br>08:50 PM</td>
<td class="g_g">RAJDHANI NIGHT OPEN<br>09:20 PM</td>
<td class="g_g">MAIN RATAN OPEN<br>09:30 PM</td>
</tr>
<tr>


<td class="g_d">SRIDEVI DAY CLOSE<br>12.20 PM</td>
<td class="g_d">MADHUR DAY CLOSE<br>02:00 PM</td>
<td class="g_d">TIME BAZAR CLOSE<br>01:50 PM</td>
<td class="g_d">MILAN DAY CLOSE<br>04:55 PM</td>
<td class="g_d">RAJDHANI DAY CLOSE<br>05:15 PM</td>
<td class="g_d">SUPERME DAY CLOSE<br>05.20 PM</td>
<td class="g_d">KALYAN CLOSE<br>05:50 PM</td>
<td class="g_d">SRIDEVI NIGHT CLOSE<br>07.50 PM</td>
<td class="g_d">SUPERME NIGHT CLOSE<br>10.30 PM</td>
<td class="g_d">MADHUR NIGHT CLOSE<br>10:10 PM</td>
<td class="g_d">MILAN NIGHT CLOSE<br>10:50 PM</td>
<td class="g_d">RAJDHANI NIGHT CLOSE<br>11:40 PM</td>
<td class="g_d">MAIN RATAN CLOSE<br>11:55 PM</td>
</tr>
</table><table class="player" align='center' cellspacing='2' cellpadding='6' border='0' width="100%"><tr><td><div class="left_gopt">Game: 1:100</div><input type="hidden" name="game" value="JC"></td><td></td><td></td><td></td><td></td><td class="colored totx">Points</td></tr><tr><td class="colored">10&nbsp;<input id="x_0_0" onKeyup="refresh('0');" name="txt[10]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">11&nbsp;<input id="x_0_1" onKeyup="refresh('0');" name="txt[11]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">12&nbsp;<input id="x_0_2" onKeyup="refresh('0');" name="txt[12]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">13&nbsp;<input id="x_0_3" onKeyup="refresh('0');" name="txt[13]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">14&nbsp;<input id="x_0_4" onKeyup="refresh('0');" name="txt[14]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_0">00</div></td></tr><tr><td class="colored">15&nbsp;<input id="x_1_0" onKeyup="refresh('1');" name="txt[15]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">16&nbsp;<input id="x_1_1" onKeyup="refresh('1');" name="txt[16]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">17&nbsp;<input id="x_1_2" onKeyup="refresh('1');" name="txt[17]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">18&nbsp;<input id="x_1_3" onKeyup="refresh('1');" name="txt[18]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">19&nbsp;<input id="x_1_4" onKeyup="refresh('1');" name="txt[19]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_1">00</div></td></tr><tr><td class="colored">20&nbsp;<input id="x_2_0" onKeyup="refresh('2');" name="txt[20]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">21&nbsp;<input id="x_2_1" onKeyup="refresh('2');" name="txt[21]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">22&nbsp;<input id="x_2_2" onKeyup="refresh('2');" name="txt[22]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">23&nbsp;<input id="x_2_3" onKeyup="refresh('2');" name="txt[23]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">24&nbsp;<input id="x_2_4" onKeyup="refresh('2');" name="txt[24]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_2">00</div></td></tr><tr><td class="colored">25&nbsp;<input id="x_3_0" onKeyup="refresh('3');" name="txt[25]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">26&nbsp;<input id="x_3_1" onKeyup="refresh('3');" name="txt[26]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">27&nbsp;<input id="x_3_2" onKeyup="refresh('3');" name="txt[27]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">28&nbsp;<input id="x_3_3" onKeyup="refresh('3');" name="txt[28]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">29&nbsp;<input id="x_3_4" onKeyup="refresh('3');" name="txt[29]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_3">00</div></td></tr><tr><td class="colored">30&nbsp;<input id="x_4_0" onKeyup="refresh('4');" name="txt[30]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">31&nbsp;<input id="x_4_1" onKeyup="refresh('4');" name="txt[31]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">32&nbsp;<input id="x_4_2" onKeyup="refresh('4');" name="txt[32]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">33&nbsp;<input id="x_4_3" onKeyup="refresh('4');" name="txt[33]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">34&nbsp;<input id="x_4_4" onKeyup="refresh('4');" name="txt[34]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_4">00</div></td></tr><tr><td class="colored">35&nbsp;<input id="x_5_0" onKeyup="refresh('5');" name="txt[35]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">36&nbsp;<input id="x_5_1" onKeyup="refresh('5');" name="txt[36]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">37&nbsp;<input id="x_5_2" onKeyup="refresh('5');" name="txt[37]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">38&nbsp;<input id="x_5_3" onKeyup="refresh('5');" name="txt[38]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">39&nbsp;<input id="x_5_4" onKeyup="refresh('5');" name="txt[39]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_5">00</div></td></tr><tr><td class="colored">40&nbsp;<input id="x_6_0" onKeyup="refresh('6');" name="txt[40]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">41&nbsp;<input id="x_6_1" onKeyup="refresh('6');" name="txt[41]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">42&nbsp;<input id="x_6_2" onKeyup="refresh('6');" name="txt[42]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">43&nbsp;<input id="x_6_3" onKeyup="refresh('6');" name="txt[43]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">44&nbsp;<input id="x_6_4" onKeyup="refresh('6');" name="txt[44]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_6">00</div></td></tr><tr><td class="colored">45&nbsp;<input id="x_7_0" onKeyup="refresh('7');" name="txt[45]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">46&nbsp;<input id="x_7_1" onKeyup="refresh('7');" name="txt[46]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">47&nbsp;<input id="x_7_2" onKeyup="refresh('7');" name="txt[47]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">48&nbsp;<input id="x_7_3" onKeyup="refresh('7');" name="txt[48]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">49&nbsp;<input id="x_7_4" onKeyup="refresh('7');" name="txt[49]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_7">00</div></td></tr><tr><td class="colored">50&nbsp;<input id="x_8_0" onKeyup="refresh('8');" name="txt[50]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">51&nbsp;<input id="x_8_1" onKeyup="refresh('8');" name="txt[51]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">52&nbsp;<input id="x_8_2" onKeyup="refresh('8');" name="txt[52]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">53&nbsp;<input id="x_8_3" onKeyup="refresh('8');" name="txt[53]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">54&nbsp;<input id="x_8_4" onKeyup="refresh('8');" name="txt[54]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_8">00</div></td></tr><tr><td class="colored">55&nbsp;<input id="x_9_0" onKeyup="refresh('9');" name="txt[55]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">56&nbsp;<input id="x_9_1" onKeyup="refresh('9');" name="txt[56]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">57&nbsp;<input id="x_9_2" onKeyup="refresh('9');" name="txt[57]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">58&nbsp;<input id="x_9_3" onKeyup="refresh('9');" name="txt[58]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">59&nbsp;<input id="x_9_4" onKeyup="refresh('9');" name="txt[59]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_9">00</div></td></tr><tr><td class="colored">60&nbsp;<input id="x_10_0" onKeyup="refresh('10');" name="txt[60]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">61&nbsp;<input id="x_10_1" onKeyup="refresh('10');" name="txt[61]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">62&nbsp;<input id="x_10_2" onKeyup="refresh('10');" name="txt[62]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">63&nbsp;<input id="x_10_3" onKeyup="refresh('10');" name="txt[63]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">64&nbsp;<input id="x_10_4" onKeyup="refresh('10');" name="txt[64]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_10">00</div></td></tr><tr><td class="colored">65&nbsp;<input id="x_11_0" onKeyup="refresh('11');" name="txt[65]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">66&nbsp;<input id="x_11_1" onKeyup="refresh('11');" name="txt[66]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">67&nbsp;<input id="x_11_2" onKeyup="refresh('11');" name="txt[67]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">68&nbsp;<input id="x_11_3" onKeyup="refresh('11');" name="txt[68]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">69&nbsp;<input id="x_11_4" onKeyup="refresh('11');" name="txt[69]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_11">00</div></td></tr><tr><td class="colored">70&nbsp;<input id="x_12_0" onKeyup="refresh('12');" name="txt[70]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">71&nbsp;<input id="x_12_1" onKeyup="refresh('12');" name="txt[71]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">72&nbsp;<input id="x_12_2" onKeyup="refresh('12');" name="txt[72]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">73&nbsp;<input id="x_12_3" onKeyup="refresh('12');" name="txt[73]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">74&nbsp;<input id="x_12_4" onKeyup="refresh('12');" name="txt[74]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_12">00</div></td></tr><tr><td class="colored">75&nbsp;<input id="x_13_0" onKeyup="refresh('13');" name="txt[75]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">76&nbsp;<input id="x_13_1" onKeyup="refresh('13');" name="txt[76]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">77&nbsp;<input id="x_13_2" onKeyup="refresh('13');" name="txt[77]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">78&nbsp;<input id="x_13_3" onKeyup="refresh('13');" name="txt[78]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">79&nbsp;<input id="x_13_4" onKeyup="refresh('13');" name="txt[79]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_13">00</div></td></tr><tr><td class="colored">80&nbsp;<input id="x_14_0" onKeyup="refresh('14');" name="txt[80]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">81&nbsp;<input id="x_14_1" onKeyup="refresh('14');" name="txt[81]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">82&nbsp;<input id="x_14_2" onKeyup="refresh('14');" name="txt[82]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">83&nbsp;<input id="x_14_3" onKeyup="refresh('14');" name="txt[83]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">84&nbsp;<input id="x_14_4" onKeyup="refresh('14');" name="txt[84]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_14">00</div></td></tr><tr><td class="colored">85&nbsp;<input id="x_15_0" onKeyup="refresh('15');" name="txt[85]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">86&nbsp;<input id="x_15_1" onKeyup="refresh('15');" name="txt[86]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">87&nbsp;<input id="x_15_2" onKeyup="refresh('15');" name="txt[87]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">88&nbsp;<input id="x_15_3" onKeyup="refresh('15');" name="txt[88]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">89&nbsp;<input id="x_15_4" onKeyup="refresh('15');" name="txt[89]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_15">00</div></td></tr><tr><td class="colored">90&nbsp;<input id="x_16_0" onKeyup="refresh('16');" name="txt[90]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">91&nbsp;<input id="x_16_1" onKeyup="refresh('16');" name="txt[91]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">92&nbsp;<input id="x_16_2" onKeyup="refresh('16');" name="txt[92]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">93&nbsp;<input id="x_16_3" onKeyup="refresh('16');" name="txt[93]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">94&nbsp;<input id="x_16_4" onKeyup="refresh('16');" name="txt[94]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_16">00</div></td></tr><tr><td class="colored">95&nbsp;<input id="x_17_0" onKeyup="refresh('17');" name="txt[95]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">96&nbsp;<input id="x_17_1" onKeyup="refresh('17');" name="txt[96]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">97&nbsp;<input id="x_17_2" onKeyup="refresh('17');" name="txt[97]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">98&nbsp;<input id="x_17_3" onKeyup="refresh('17');" name="txt[98]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">99&nbsp;<input id="x_17_4" onKeyup="refresh('17');" name="txt[99]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_17">00</div></td></tr><tr><td class="colored">00&nbsp;<input id="x_18_0" onKeyup="refresh('18');" name="txt[00]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">01&nbsp;<input id="x_18_1" onKeyup="refresh('18');" name="txt[01]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">02&nbsp;<input id="x_18_2" onKeyup="refresh('18');" name="txt[02]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">03&nbsp;<input id="x_18_3" onKeyup="refresh('18');" name="txt[03]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">04&nbsp;<input id="x_18_4" onKeyup="refresh('18');" name="txt[04]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_18">00</div></td></tr><tr><td class="colored">05&nbsp;<input id="x_19_0" onKeyup="refresh('19');" name="txt[05]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">06&nbsp;<input id="x_19_1" onKeyup="refresh('19');" name="txt[06]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">07&nbsp;<input id="x_19_2" onKeyup="refresh('19');" name="txt[07]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">08&nbsp;<input id="x_19_3" onKeyup="refresh('19');" name="txt[08]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">09&nbsp;<input id="x_19_4" onKeyup="refresh('19');" name="txt[09]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_19">00</div></td></tr><tr><td></td><td></td><td></td><td></td><td class="colored smx"><b>Total -></b></td><td class="colored totx"><span id="whole">00</div></td></tr></table>
<div style="color: red; padding:5px;" align="center">
You can not play game. Your account balance should be greater than 5. contact to administrator.</div>
<center><font color=blue>*After Confirm Submission no changes will be made at any cost and it will be fixed bidding</font><br><b>Note - Minimum Bet on any any number should be 10 points</b></center>
<script>
function refresh(id)
{
sum=0;

for(i=0; i<5; i++)
{
points = document.getElementById("x_" + id + "_" + i).value;
if(points > )
{
alert("You dont have that much point.");
}else{
sum = +sum + +points;
}
document.getElementById("t_r_" + id).innerHTML = sum;
}
refreshall('20');
}

function refreshall(all)
{
sum = 0;
for(i=0; i<all; i++)
{
sum = +sum + +document.getElementsByClassName("smd")[i].innerHTML;
}
document.getElementById("whole").innerHTML = sum;
if(sum > )
{
alert("You dont have that much point.");
}
}

function rst(tot)
{
document.getElementById("form1").reset();
document.getElementById("whole").innerHTML = "00";
for(i=0; i<tot; i++)
{
document.getElementsByClassName("smd")[i].innerHTML = "00";
}
}

</script>


</div></td></tr> </table></div> 

<div class="footer">&copy; 2011-2035  Ratan Matka Inc.</div>