 
<!DOCTYPE html>
<html lang="en">
<head>
<title>Play Matka online  Satta Matka of all markets Play Tripple Patti</title>
<meta name="description" content="Play Online Satta Matka of all markets Play Tripple Patti">


<link rel="stylesheet" href="/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-80894722-1', 'auto');
  ga('send', 'pageview');

</script>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>	
  
</head>
<body>
<div align="center" class="satta_2">
<div style="color: Red;"><span style="color: #F0FFF0;"><span style="font-family: Calibri;"><span style="font-size: x-large;"><strong><em><big><bdo dir="ltr">Ratan Matka</bdo></big></em></strong></span></span></span></div><a href="http://ratanmatka.in">RatanMatka.iN</a>
</div>
<div class="detail"><marquee behavior="alternate">After Registration, for online play Contact us on +919672737576
</marquee></div> PHONE PE:9672737576<br>GOOGLE PAY:9672737576<br>PAYTM:9672737576<br>BHIM 9672737576<br><div class="purple"><form action="login.php" name="login" method="post"><input type="hidden" name="s" value="1" />Username: <input type="text" name="username">&nbsp;Password: <input type="password" name="password">&nbsp;&nbsp;<input type="submit" value="Login">&nbsp;&nbsp;&nbsp;&nbsp;New user <a href="register.php"><input type="button" name="register" value="Register" class="btn"></a> &nbsp;&nbsp; here&nbsp;&nbsp;</form></div><div style="background-color: orange">
<center>TODAY'S  DATE: 17/07/2020<br /><font size ="15"><div id="myClock"></div></font>
<script type="text/javascript" language="javascript">

// select the myClock div
var myClock = document.getElementById('myClock');

function renderTime () {

    var currentTime = new Date();
    var h = currentTime.getHours();
    var m = currentTime.getMinutes();
    var s = currentTime.getSeconds();
if (h<12) { pkk= "AM"; } else {pkk= "PM"; }

    if(h==0){h=12;}
	else if(h>12){h-=12;}
    
    
    if (m < 10) 
    { m = "0" + m;
    }
    
    
    if (s < 10) 
    { s = "0" + s;
    }
    
    myClock.textContent = h + ":" + m + ":" + s   +   pkk;
    myClock.innerText = h + ":" + m + ":" + s   +   pkk;

} // don't forget to close your function

// you actually want to use setInterval, not setTimeout
setInterval(function(){
    renderTime();
}, 1000);
</script>
</div></center><form action="play.php" id="form1" method="post"><input type="hidden" name="s" value="1" /><input name="selrs" type="text" value="" style="display: none">
<table width="100%" lol ><tr>

<td class="g_d">SRIDEVI DAY OPEN<br>11.20 AM</td>
<td class="g_d">MADHUR DAY OPEN<br>1:00 PM</td>
<td class="g_d">TIME BAZAR OPEN<br>12:50 PM</td>
<td class="g_d">MILAN DAY OPEN<br>02:55 PM</td>
<td class="g_d">RAJDHANI DAY OPEN<br>03:15 PM</td>
<td class="g_d">SUPERME DAY OPEN<br>03.20 PM</td>
<td class="g_d">KALYAN OPEN<br>03:50 PM</td>
<td class="g_g">SRIDEVI NIGHT OPEN<br>06.50 PM</td>
<td class="g_g">SUPERME NIGHT OPEN<br>08.30 PM</td>
<td class="g_g">MADHUR NIGHT OPEN<br>08:10 PM</td>
<td class="g_g">MILAN NIGHT OPEN<br>08:50 PM</td>
<td class="g_g">RAJDHANI NIGHT OPEN<br>09:20 PM</td>
<td class="g_g">MAIN RATAN OPEN<br>09:30 PM</td>
</tr>
<tr>


<td class="g_d">SRIDEVI DAY CLOSE<br>12.20 PM</td>
<td class="g_d">MADHUR DAY CLOSE<br>02:00 PM</td>
<td class="g_d">TIME BAZAR CLOSE<br>01:50 PM</td>
<td class="g_g">MILAN DAY CLOSE<br>04:55 PM</td>
<td class="g_g">RAJDHANI DAY CLOSE<br>05:15 PM</td>
<td class="g_g">SUPERME DAY CLOSE<br>05.20 PM</td>
<td class="g_g">KALYAN CLOSE<br>05:50 PM</td>
<td class="g_g">SRIDEVI NIGHT CLOSE<br>07.50 PM</td>
<td class="g_g">SUPERME NIGHT CLOSE<br>10.30 PM</td>
<td class="g_g">MADHUR NIGHT CLOSE<br>10:10 PM</td>
<td class="g_g">MILAN NIGHT CLOSE<br>10:50 PM</td>
<td class="g_g">RAJDHANI NIGHT CLOSE<br>11:40 PM</td>
<td class="g_g">MAIN RATAN CLOSE<br>11:55 PM</td>
</tr>
</table><table class="player" align='center' cellspacing='2' cellpadding='6' border='0' width="100%"><tr><td><div class="left_gopt">Game: 1:700</div><input type="hidden" name="game" value="TP"></td><td></td><td></td><td></td><td></td><td class="colored totx">Points</td></tr><tr><td class="colored">000&nbsp;<input id="x_0_0" onKeyup="refresh('0');" name="txt[000]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">111&nbsp;<input id="x_0_1" onKeyup="refresh('0');" name="txt[111]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">222&nbsp;<input id="x_0_2" onKeyup="refresh('0');" name="txt[222]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">333&nbsp;<input id="x_0_3" onKeyup="refresh('0');" name="txt[333]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">444&nbsp;<input id="x_0_4" onKeyup="refresh('0');" name="txt[444]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_0">00</div></td></tr><tr><td class="colored">555&nbsp;<input id="x_1_0" onKeyup="refresh('1');" name="txt[555]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">666&nbsp;<input id="x_1_1" onKeyup="refresh('1');" name="txt[666]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">777&nbsp;<input id="x_1_2" onKeyup="refresh('1');" name="txt[777]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">888&nbsp;<input id="x_1_3" onKeyup="refresh('1');" name="txt[888]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored">999&nbsp;<input id="x_1_4" onKeyup="refresh('1');" name="txt[999]" type="text" onkeypress="return isNumberKey(event)" style="height: 15px; width: 45px; vertical-align: baseline; border-color: red" /></td><td class="colored totx"><span class="smd" id="t_r_1">00</div></td></tr><tr><td></td><td></td><td></td><td></td><td class="colored smx"><b>Total -></b></td><td class="colored totx"><span id="whole">00</div></td></tr></table>
<div style="color: red; padding:5px;" align="center">
You can not play game. Your account balance should be greater than 5. contact to administrator.</div>
<center><font color=blue>*After Confirm Submission no changes will be made at any cost and it will be fixed bidding</font><br><b><br>Note - Minimum Bet on any any number should be 10 points</b></center>
<script>
function refresh(id)
{
sum=0;

for(i=0; i<5; i++)
{
points = document.getElementById("x_" + id + "_" + i).value;
if(points > )
{
alert("You dont have that much point.");
}else{
sum = +sum + +points;
}
document.getElementById("t_r_" + id).innerHTML = sum;
}
refreshall('2');
}

function refreshall(all)
{
sum = 0;
for(i=0; i<all; i++)
{
sum = +sum + +document.getElementsByClassName("smd")[i].innerHTML;
}
document.getElementById("whole").innerHTML = sum;
if(sum > )
{
alert("You dont have that much point.");
}
}

function rst(tot)
{
document.getElementById("form1").reset();
document.getElementById("whole").innerHTML = "00";
for(i=0; i<tot; i++)
{
document.getElementsByClassName("smd")[i].innerHTML = "00";
}
}

</script>
</div></td></tr> </table></div> 

<div class="footer">&copy; 2011-2035  Ratan Matka Inc.</div>