
<!DOCTYPE html>
<html lang="en">
<head>
<title>Play Matka online  Satta Matka of all markets Game Information how to play</title>
<meta name="description" content="Play Online Satta Matka of all markets Game Information how to play">


<link rel="stylesheet" href="/styles.css" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-80894722-1', 'auto');
  ga('send', 'pageview');

</script>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>	
  
</head>
<body>
<div align="center" class="satta_2">
<div style="color: Red;"><span style="color: #F0FFF0;"><span style="font-family: Calibri;"><span style="font-size: x-large;"><strong><em><big><bdo dir="ltr">Ratan Matka</bdo></big></em></strong></span></span></span></div><a href="http://ratanmatka.in">RatanMatka.iN</a>
</div>
<div class="purple"><form action="login.php" name="login" method="post"><input type="hidden" name="s" value="1" />Username: <input type="text" name="username">&nbsp;Password: <input type="password" name="password">&nbsp;&nbsp;<input type="submit" value="Login">&nbsp;&nbsp;&nbsp;&nbsp;New user <a href="register.php"><input type="button" name="register" value="Register" class="btn"></a> &nbsp;&nbsp; here&nbsp;&nbsp;</form></div>
  </b><br> Game rate full<br/>10:100(Single Digit)<br/>10:1000(Jodi)<br/>10:1500(Single Panel)<br/>10:3000(Double Panel)<br/>10:7000(Triple Panel)<br>10:10000 (Half sangam)<br>10:100000 (full sangam)<br><br>ONLY WHATSAPP SMS
  9672737576
</b><br> <h5>   WITHDRAWAL TIME MORNING 7 am To 11.00 am   <br><br><br>NOTICE <br><br><br> 
      DEPOSIT  BOUNS
ALL TIME<br>10000 per 1000<br >20000 per 2000<br >50000 per 6000
6000<br><br>NOTICE<br>Play last time update<br><br></div></td></tr> </table></div> 

<div class="footer">&copy; 2011-2035  Ratan Matka Inc.</div>