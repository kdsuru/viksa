
<!DOCTYPE html>
<html lang="en">
<head>
<title>online play matka ,play matka online ,online matka play,online matka, matka online, online matka play, matka play, online satta matka, satta matka online, satta matka online play, satta matka online play , satta matka fix game ,satta matka fix jodi ,satta matka fast Result ,satta matka sure number, satta matka today game,satta matka fix </title>
<meta name="description" content="online play matka ,play matka online ,online matka play,online matka, matka online, online matka play, matka play, online satta matka, satta matka online, satta matka online play, satta matka online play , satta matka fix game ,satta matka fix jodi ,satta matka fast Result ,satta matka sure number, satta matka today game,satta matka fix ">


<link rel="stylesheet" href="/styles.css" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-80894722-1', 'auto');
  ga('send', 'pageview');

</script>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>	
  
</head>
<body>
<div align="center" class="satta_2">
<div style="color: Red;"><span style="color: #F0FFF0;"><span style="font-family: Calibri;"><span style="font-size: x-large;"><strong><em><big><bdo dir="ltr">Ratan Matka</bdo></big></em></strong></span></span></span></div><a href="http://ratanmatka.in">RatanMatka.iN</a>
</div>
<div class="purple"><form action="login.php" name="login" method="post"><input type="hidden" name="s" value="1" />Username: <input type="text" name="username">&nbsp;Password: <input type="password" name="password">&nbsp;&nbsp;<input type="submit" value="Login">&nbsp;&nbsp;&nbsp;&nbsp;New user <a href="register.php"><input type="button" name="register" value="Register" class="btn"></a> &nbsp;&nbsp; here&nbsp;&nbsp;</form></div>
<center><b><font color="brown" size="4">AAPKA BHAROSA HUMARI IMANDARI</font></b><br><br>
<b><font color="blue" size="3">HOW TO PLAY ONLINE MATKA:</font></b></center><br><br>
ONLINE GAME  KHELNE  KE  LIYE  SABSE  PEHLE  AAP  HUME  PAISE  DEPOSIT  KARWAYE,  MINIMUM  AMOUNT  1000  USSE  KAM  DEPOSIT  NAHI  LIYA  JATA,<br>
USKE BAAD AAP JITNE PAISE HUME DEPOSIT KARWAYENGE UTNE POINT AAPKI USER ID ME ADD KAR DIYE JAAYENGE.<br><br>
<center><b><font color="red" size="3">1 Rs.==1 POINT</font></b></center><br><br>
JO GAME AAP KHELENGE AGAR AAP KA GAME LAGTA HAI TO AAPKE POINTS AUTOMATICALLY BADH JAAYENGE,<br>
AND JAB AAPKO PAYMENT CHAHIYE HO TAB AAP HUME CALL YA MESSEGE KARKE INFORM KARE,  JISSE KI HUM AAPKE A/C ME PAYMENT TRANFER KAR SAKE.<br>
BET KARNE KA MINIMUM AMOUNT 10 Rs.USSE KAM SE GAME NA KHELE.<br>
KISI HELP AND A/C ME PAISE DEPOSIT KARWANE KE LIYE AAP HUM NEECHE DIYE GAYE NUMBERS PAR CONTACT KARE…..<br>
<font color="violet" size="4">THNXXXX<br>
REGARDS</font><br>
<font color="brown" size="4">PLAY MATKA GROUP  <br>
CONTACT NO.:- +91 9672737576
</font><br><br><br>




<center><b><font color="blue" size="3">How to play online :-</font></b></center><br>
1.	First of all Kindly Deposit money to our a/c.<br>
2.	minimum deposit of Rs 1000 Rs., below 1000 Rs. will not be accepted .<br>
3.	Secondly the amount of money you deposit accordingly the points will be added to your corresponding ID <br>
<b><font color="red" size="3">1 Rs.==1 POINT</font></b><br>
**minimum amount to bet is Rs. 10.<br>
3.The game you played and got lucky enough to win it then accordingly your points will be increased. <br>
 4. If you wish to encash the points of your ID then kindly call or message us and your money will be transferred to your account as soon as possible .<br>
**In case of any inconvenience regarding the transaction of money OR further query then you can contact us on the following numbers.<br>
<font color="violet" size="4">THNXXXX<br>
REGARDS</font><br>
<font color="brown" size="4">ONLINE PLAY MATKA GROUP  <br>
CONTACT NO.:- +91 9672737576
</font><br><br><br>
</div></td></tr> </table></div> 

<div class="footer">&copy; 2011-2035  Ratan Matka Inc.</div>